#
# Copyright (C) Microsoft. All rights reserved.
#

<#
.Synopsis
    Enumerate all active keyboard filter rules on the system.
.Description
    For each instance of WEKF_PredefinedKey, WEKF_CustomKey, and WEKF_Scancode,
    get the Enabled property.  If Enabled, then output a short description
    of the rule.
.Parameter ComputerName
    Optional parameter to specify the remote machine that this script should
    manage.  If not specified, the script will execute all WMI operations
    locally.
#>
param (
    [String] $ComputerName
)

$CommonParams = @{"namespace"="root\standardcimv2\embedded"}
$CommonParams += $PSBoundParameters

write-host Enabled Predefined Keys -foregroundcolor cyan
Get-WMIObject -class WEKF_PredefinedKey @CommonParams |
    foreach {
        if ($_.Enabled) {
            write-host $_.Id
        }
    }

write-host Enabled Custom Keys -foregroundcolor cyan
Get-WMIObject -class WEKF_CustomKey @CommonParams |
    foreach {
        if ($_.Enabled) {
            write-host $_.Id
        }
    }

write-host Enabled Scancodes -foregroundcolor cyan
Get-WMIObject -class WEKF_Scancode @CommonParams |
    foreach {
        if ($_.Enabled) {
            "{0}+{1:X4}" -f $_.Modifiers, $_.Scancode
        }
    }