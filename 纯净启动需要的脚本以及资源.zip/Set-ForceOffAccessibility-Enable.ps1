#
# Copyright (C) Microsoft. All rights reserved.
#

<#
.Synopsis
    This script shows how to enumerate WEKF_Settings to find global settings
    that can be set on the keyboard filter.  In this specific script, the
    global setting to be set is "ForceOffAccessibility".
.Parameter ComputerName
    Optional parameter to specify a remote computer that this script should
    manage.  If not specified, the script will execute all WMI operations
    locally.
.Parameter Enabled
    Switch if present that sets "ForceOffAccessibility" to true.  If not
    present, sets the setting to false.
#>

param (
    [Switch] $Enabled = $False,
    [String] $ComputerName
)

$CommonParams = @{"namespace"="root\standardcimv2\embedded"};
if ($PSBoundParameters.ContainsKey("ComputerName")) {
    $CommonParams += @{"ComputerName" = $ComputerName};
}

function Get-Setting([String] $Name) {
    <#
    .Synopsis
        Get a WMIObject by name from WEKF_Settings
    .Parameter Name
        The name of the setting, which is the key for the WEKF_Settings class.
#>
    $Entry = Get-WMIObject -class WEKF_Settings @CommonParams |
        where {
            $_.Name -eq $Name
        }

    return $Entry
}

function Set-ForceOffAccessibility([Bool] $Value) {
    <#
    .Synopsis
        Set the ForceOffAccessibility setting to true or false.
    .Description
        Set ForceOffAccessibility to true or false based on $Value
    .Parameter Value
        A Boolean value
#>

    $Setting = Get-Setting("ForceOffAccessibility")
    if ($Setting) {
        if ($Value) {
            $Setting.Value = "true" 
        } else {
            $Setting.Value = "false"
        }
        $Setting.Put() | Out-Null;
    } else {
        Write-Error "Unable to find ForceOffAccessibility setting";
    }
}

Set-ForceOffAccessibility $Enabled